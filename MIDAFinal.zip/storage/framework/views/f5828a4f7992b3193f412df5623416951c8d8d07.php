<div class="menu" id="Menu">
    <h1>Nos<span>restaurant</span></h1>

    <div class="menu_box">
        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="menu_card">

            <div class="menu_image">
                <img src="<?php echo e(url('resto_affiche/'.$restaurant->resto_affiche)); ?>">
            </div>

            <div class="small_card">
                <i class="fa-solid fa-heart"></i>
            </div>

            <div class="menu_info">
                <h2><?php echo e($restaurant->resto_name); ?></h2>
                <p>
                    <?php echo e($restaurant->resto_desc); ?>

                </p>
                <h3>Prix moyen <?php echo e($restaurant->resto_price); ?> FCFA</h3>
                <div class="menu_icon">
                    <p><?php echo e($restaurant->adresse); ?></p>
                </div>
                <a href="<?php echo e(route('reservation.detailView',['id'=>$restaurant->id])); ?>" class="menu_btn">Reservez</a>
                
            </div>

        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
</div>
<?php /**PATH C:\Users\nkoub\OneDrive\Documents\UCAO COURS\sem 6\projet MIDA\projectMIDA (2)\MIDAFinal\resources\views/layouts/menusection.blade.php ENDPATH**/ ?>