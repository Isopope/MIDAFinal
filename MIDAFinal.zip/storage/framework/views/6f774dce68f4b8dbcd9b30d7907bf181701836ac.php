<nav>
    <div class="logo">
        <img src="<?php echo e(url('image/logo.png')); ?>">
    </div>
    <?php if(Route::has('login')): ?>
        <?php if(auth()->guard()->check()): ?>
        <ul>
            <li><a href="<?php echo e(route('RedirigerVers')); ?>">Acceuil</a></li>
            <li><a href="#About">A propos de nous</a></li>
            <li><a href="/reservations">Vos reservations</a></li>
            <li><a href="#"> Bienvenue <?php echo e(Auth::User()->name); ?></a></li>
            
        </ul>
        <div class="logo">
            <li style="list-style: none">Bienvenue <?php echo e(Auth::User()->name); ?></li>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                
                <input type="submit" class="btn" value="Se deconnecter" style="background: rgb(160, 21, 21); color:white ; width:150px; padding:12px 25px;" />
            </form>
        </div>

        <?php else: ?>
        <ul>
            <li><a href="/">Acceuil</a></li>
            <li><a href="#About">A propos de nous</a></li>
            <li><a href="<?php echo e(route('login')); ?>">Se connecter</a></li>
            <li><a href="<?php echo e(route('register')); ?>">Inscription</a></li>
        </ul>
        <?php endif; ?>
    
    
    <?php endif; ?>
    
    

</nav><?php /**PATH C:\Users\nkoub\OneDrive\Documents\UCAO COURS\sem 6\projet MIDA\projectMIDA (2)\MIDAFinal\resources\views/layouts/navbarconected.blade.php ENDPATH**/ ?>