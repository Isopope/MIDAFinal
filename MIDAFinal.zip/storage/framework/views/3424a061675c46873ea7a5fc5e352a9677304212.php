
<?php $__env->startSection('contentbase'); ?>
    <?php echo $__env->make('layouts.sectionhome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nkoub\OneDrive\Documents\UCAO COURS\sem 6\projet MIDA\projectMIDA (2)\MIDAFinal\resources\views//reservationsclient.blade.php ENDPATH**/ ?>