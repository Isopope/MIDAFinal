@extends('layouts.base')
@section('contentbase')
    @include('layouts.sectionhome') 
    @include('layouts.table')
    @include('layouts.footer')
@endsection
