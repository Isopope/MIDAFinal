<footer>
    <div class="footer_main">

        <div class="footer_tag">
            <h2>Location</h2>
            <p>Nous sommes situé à Lomé au Togo plus précisement à Sanguera UCAO, se sera un plaisir pour nous de vous reçevoir dans nos locaux pour plus amples informations ou services</p>
           
        </div>

        <div class="footer_tag">
            <h2 id="About">A propos de nous</h2>
            <p>Rest-place a vu le jours dans l'optique de fournir, un service de reservation facile et accessible à tous ainsi que dans le cadre de 
            la presentation du projet final du cours de Projet MIDA dispensé à l'UCAO-UUT en semestre 6 parcours MIDA(Mathématiques-Informatique et Developpement d'applications) <i class="fa-solid fa-face-grin"></i></p>
        </div>

        <div class="footer_tag">
            <h2>Contacts</h2>
            <p>+228 91723378</p>
            <p>+228 97782195</p>
            <p>rest-place@rest-place.com</p>
            <p>nkoubah@gmail.com</p>
        </div>

        <div class="footer_tag">
            <h2>Nos services</h2>
            <p>Recherches faciles</p>
            <p>Reservations faciles</p>
            <p>Disponibilités 24/7</p>
        </div>

        <div class="footer_tag">
            <h2 style="font-size:20px;">Suivez Rest-place sur les réseaux sociaux</h2>
            <i class="fa-brands fa-facebook-f"></i>
            <i class="fa-brands fa-twitter"></i>
            <i class="fa-brands fa-instagram"></i>
            <i class="fa-brands fa-linkedin-in"></i>
        </div>

    </div>

    <p class="end">Design by<span><i class="fa-solid fa-face-grin"></i> Rest-place</span></p>

</footer>