@extends('layouts.base')
@section('contentbase')
    @include('layouts.sectionhome')
    @include('layouts.menusection')
    @include('layouts.footer')
@endsection
